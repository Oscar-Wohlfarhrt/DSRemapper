﻿function ScrollToBottom(ele){
    ele.scrollTop=ele.scrollHeight;
}
function AddHTML(ele, text){
    ele.innerHTML+=text;
}
function SetHTML(ele, text){
    ele.innerHTML=text;
}